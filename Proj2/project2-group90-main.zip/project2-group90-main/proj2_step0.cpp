#include <px4_platform_common/px4_config.h>
#include <px4_platform_common/log.h>
#include <uORB/topics/rc_channels.h>
extern "C" __EXPORT int hello_world_main(int argc, char *argv[]);

int hello_world_main(int argc, char *argv[])
{
	int channels_handle;
	rc_channels_s channels;
	channels_handle = orb_subscribe(ORB_ID(rc_channels));
	orb_set_interval(channels_handle, 200);
	while(1)
	{
		orb_copy(ORB_ID(rc_channels), channels_handle, &channels);
		PX4_INFO("Channel 1 = %f, Channel 2 = %f, Channel 3 = %f, Channel 4 = %f",
				(double)channels.channels[0],
				(double)channels.channels[1],
				(double)channels.channels[2],
				(double)channels.channels[3]
		);
		px4_usleep(200000);
	}
	return 0;
}
