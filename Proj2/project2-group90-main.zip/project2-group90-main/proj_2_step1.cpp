#include <px4_platform_common/px4_config.h>
#include <px4_platform_common/log.h>
#include <uORB/topics/rc_channels.h>

#include <drivers/drv_hrt.h>
#include <uORB/Publication.hpp>
#include <uORB/topics/test_motor.h>

#define DC_MOTOR 0
#define SERVO_MOTOR 1

extern "C" __EXPORT int hello_world_main(int argc, char *argv[]);

int hello_world_main(int argc, char *argv[])
{
	test_motor_s dc_motor;
	test_motor_s servo_motor;

	double motor_speed = 0; // a number between 0 to 1
	double motor_angle = 0;
	int channels_handle;
	rc_channels_s channels;
	channels_handle = orb_subscribe(ORB_ID(rc_channels));
	orb_set_interval(channels_handle, 200);

	uORB::Publication<test_motor_s> test_motor_pub(ORB_ID(test_motor));

	while(1)
	{
//		PX4_INFO("Enter speed value (0 to 1). If you enter a value outside the range, the motor will be stopped and the application will be terminated.");
//		scanf("%lf, %lf", &motor_speed, &motor_angle);
//		if((motor_speed > 1.0 || motor_speed < 0) || (motor_angle > 1.0 || motor_angle < 0))
//			break;
		orb_copy(ORB_ID(rc_channels), channels_handle, &channels);

		// channel 3 is speed, channel 1 is angle

		motor_speed = ((double)channels.channels[2] + 1.0) / 2.0;
		motor_angle = 1.0 - ((double)channels.channels[0] + 1.0) / 2.0;

//		PX4_INFO("Motor speed is %f", motor_speed);
		dc_motor.timestamp = hrt_absolute_time();
		dc_motor.motor_number = DC_MOTOR;
		dc_motor.value = (float)motor_speed;
		dc_motor.action = test_motor_s::ACTION_RUN;
		dc_motor.driver_instance = 0;
		dc_motor.timeout_ms = 0;

//		PX4_INFO("Motor angle is %f", motor_angle);
		servo_motor.timestamp = hrt_absolute_time();
		servo_motor.motor_number = SERVO_MOTOR;
		servo_motor.value = (float)motor_angle;
		servo_motor.action = test_motor_s::ACTION_RUN;
		servo_motor.driver_instance = 0;
		servo_motor.timeout_ms = 0;

		test_motor_pub.publish(dc_motor);
		test_motor_pub.publish(servo_motor);

		px4_usleep(10000);


	}

//	PX4_INFO("The motor will be stopped");
//	dc_motor.timestamp = hrt_absolute_time();
//	dc_motor.motor_number = DC_MOTOR;
//	dc_motor.value = 0.5;
//	dc_motor.driver_instance = 0;
//	dc_motor.timeout_ms = 0;
//
//	servo_motor.timestamp = hrt_absolute_time();
//	servo_motor.motor_number = SERVO_MOTOR;
//	servo_motor.value = 0.5;
//	servo_motor.driver_instance = 0;
//	servo_motor.timeout_ms = 0;
//
//	test_motor_pub.publish(dc_motor);
//	test_motor_pub.publish(servo_motor);

	return 0;
}
