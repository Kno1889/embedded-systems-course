#include <px4_platform_common/px4_config.h>
#include <px4_platform_common/log.h>
#include <uORB/Publication.hpp>

#include <drivers/drv_hrt.h>
#include <uORB/Publication.hpp>
#include <uORB/topics/test_motor.h>
#include <uORB/topics/debug_value.h>

#define DC_MOTOR 0
#define SERVO_MOTOR 1


extern "C" __EXPORT int hello_world_main(int argc, char *argv[]);

int hello_world_main(int argc, char *argv[])
{
	test_motor_s dc_motor;
	test_motor_s servo_motor;
	px4_sleep(2);
	debug_value_s debug_data;

	int debug_handle = orb_subscribe(ORB_ID(debug_value));
	orb_set_interval(debug_handle, 500);

	double motor_speed = 0.5; // a number between 0 to 1
	double motor_angle = 0.5;

	uORB::Publication<test_motor_s> test_motor_pub(ORB_ID(test_motor));

	while(1)
	{

		orb_copy(ORB_ID(debug_value), debug_handle, &debug_data);
		printf("%d", debug_data.ind);

		if (debug_data.ind == 0){
			// stop, left
			motor_speed = 0.5;
			motor_angle = 1;
		}
		else if (debug_data.ind == 1){
			// stop, fwd
			motor_speed = 0.5;
			motor_angle = 0.5;

		}
		else if (debug_data.ind == 2){
			// stop, right
			motor_speed = 0.5;
			motor_angle = 0;

		}
		else if (debug_data.ind == 3){
			// slow, left
			motor_speed = 0.6;
			motor_angle = 1;

		}
		else if (debug_data.ind == 4){
			// slow, fwd
			motor_speed = 0.6;
			motor_angle = 0.5;

		}
		else if (debug_data.ind == 5){
			// slow, right
			motor_speed = 0.6;
			motor_angle = 0;

		}
		else if (debug_data.ind == 6){
			// fast, left
			motor_speed = 0.8;
			motor_angle = 1;

		}
		else if (debug_data.ind == 7){
			// fast, fwd
			motor_speed = 0.8;
			motor_angle = 0.5;

		}
		else if (debug_data.ind == 8){
			// fast, right
			motor_speed = 0.8;
			motor_angle = 0;

		}
		dc_motor.timestamp = hrt_absolute_time();
		dc_motor.motor_number = DC_MOTOR;
		dc_motor.value = (float)motor_speed;
		dc_motor.action = test_motor_s::ACTION_RUN;
		dc_motor.driver_instance = 0;
		dc_motor.timeout_ms = 0;

//		PX4_INFO("Motor angle is %f", motor_angle);
		servo_motor.timestamp = hrt_absolute_time();
		servo_motor.motor_number = SERVO_MOTOR;
		servo_motor.value = (float)motor_angle;
		servo_motor.action = test_motor_s::ACTION_RUN;
		servo_motor.driver_instance = 0;
		servo_motor.timeout_ms = 0;

		test_motor_pub.publish(dc_motor);
		test_motor_pub.publish(servo_motor);

		px4_usleep(10000);

	}

	return 0;
}
